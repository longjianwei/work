﻿
<div id="top" >

  <p>网站地图 | 设为首页 &nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;&nbsp;登入 | 注册 | 联系开发者 | 广告联系</p>
</div>
    <div id="hearder"><h1><a href="index.php">永兴煤业六区工程部</a></h1></div>
	<div id="search">
		<div id="alist">	
			<a href="#">全部</a>
			<a href="#">报表</a>
			<a href="#">新闻</a>
			<a href="#">简历</a>
			<a href="#">论坛</a>
			<a href="#">图片</a>
		</div>
		<form action="" method="get">
		<input id="input1" type=text name="search" value="请输入要搜索的信息"/>
		<div id="input2">搜&nbsp索</div>
		<div id="input3">发布广播信息</div>
		</form>
	</div>
	<div id="nav">
		<ul>
			<li><a href="index.php">首页</a></li>
			<li><a href="#">本站新闻</a></li>
			<li><a href="#">产品展示</a></li>
			<li><a href="managementSystem.php">管理系统</a></li>
			<li><a href="#">系统广播</a></li>
			<li><a href="#">留言信息</a></li>
			<li><a href="#">产品报价</a></li>
			<li><a href="#">本站论坛</a></li>
			<li><a href="#">联系我们</a></li>
		</ul>
	</div>
	<div id="topline">	
	</div>
