﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>永兴煤业六区工程部首页</title>
<link rel="stylesheet" type="text/css" href="styles/index.css">
</head>

<body>
<div id="top" >
<?php include 'header.php'?>

<!--  <p>网站地图 | 设为首页 &nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;&nbsp;登入 | 注册 | 联系开发者 | 广告联系</p>
</div>
    <div id="hearder"><h1><a href="index.php">永兴煤业六区工程部</a></h1></div>
	<div id="search">
		<div id="alist">	
			<a href="#">全部</a>
			<a href="#">报表</a>
			<a href="#">新闻</a>
			<a href="#">简历</a>
			<a href="#">论坛</a>
			<a href="#">图片</a>
		</div>
		<form action="" method="get">
		<input id="input1" type=text name="search" value="请输入要搜索的信息"/>
		<div id="input2">搜&nbsp索</div>
		<div id="input3">发布广播信息</div>
		</form>
	</div>
	<div id="nav">
		<ul>
			<li><a href="index.php">首页</a></li>
			<li><a href="#">本站新闻</a></li>
			<li><a href="#">产品展示</a></li>
			<li><a href="managementSystem.php">管理系统</a></li>
			<li><a href="#">系统广播</a></li>
			<li><a href="#">留言信息</a></li>
			<li><a href="#">产品报价</a></li>
			<li><a href="#">本站论坛</a></li>
			<li><a href="#">联系我们</a></li>
		</ul>
	</div>
	<div id="topline">	
    </div> -->


   

	<div id="dynamicAd">
		动态广告部分
	</div>
	<div class="news">
		<h2>本站新闻</h2>
			<ul>
				<li>这是第一条新闻</li>
				<li>这是第一条新闻</li>
				<li>这是第一条新闻</li>
				<li>这是第一条新闻</li>
				<li>这是第一条新闻</li>
				<li>这是第一条新闻</li>
				<li>这是第一条新闻</li>
				<li>这是第一条新闻</li>
				<li>这是第一条新闻</li>
				<li>这是第一条新闻</li>

			</ul>
	</div>

		<div class="news" id="guangb">
		<h2>系统广播</h2>
			<ul>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>

			</ul>
		</div>
		<div class="news" id="shophot">
		<h2>产品展示</h2>
			<ul>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>

			</ul>
		</div>
		<div class="news" id="shophot">
		<h2>产品报价</h2>
			<ul>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>

			</ul>
		</div>
		<div class="news" id="job">
		<h2>最新招聘信息</h2>
			<ul>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>

			</ul>
		</div>
		<div class="news" id="fangc">
		<h2>最新留言</h2>
			<ul>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>
				<li>这是第一条广播</li>

			</ul>
		</div>
		<table id="biao">
		
			
		</table>

		<div id="foot">
		<p>longjianwei网络工作室版权所有(C)2012-2013</p>
		<p>关于我们 | 合作伙伴 | 友情连接 | 网站地图 | 广告联系</p>
		</div>
	
		


	
</body>
</html>
