﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<link rel="stylesheet" type="text/css" href="styles/admin.css">
<title>管理员系统操作平台</title>
</head>

<body>
<h1>管理员系统操作平台</h1>
</div>
	<div id="topline">	
 </div>
 	
	<div class="chedui">
		<h2>车队工程工程款模块</h2>
			<ul>
				<li>基本信息添入</li>
				<li>数据录入表</li>
				<li>工程款明细单</li>
		

			</ul>
	</div>

</body>
</html>
